import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/context/AuthContext";
import { SaaSDataProvider } from "@/context/SaaSDataContext";

import Index from "./pages/Index";
import Login from "./pages/Login";
import Register from "./pages/Register";
import AdminDashboard from "./pages/AdminDashboard";
import ClientPortal from "./pages/ClientPortal";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <SaaSDataProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner position="top-right" richColors />
          <BrowserRouter>
            <Routes>
              {/* Landing Page */}
              <Route path="/" element={<Index />} />

              {/* Auth */}
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />

              {/* Admin Views */}
              <Route path="/admin" element={<AdminDashboard />} />
              <Route path="/admin/clientes" element={<AdminDashboard />} />
              <Route path="/admin/cobranca" element={<AdminDashboard />} />
              <Route path="/admin/planos" element={<AdminDashboard />} />
              <Route path="/admin/ia-copilot" element={<AdminDashboard />} />
              <Route path="/admin/webhooks" element={<AdminDashboard />} />

              {/* Client 3D Printing Views */}
              <Route path="/cliente" element={<ClientPortal />} />
              <Route path="/cliente/calculadora" element={<ClientPortal />} />
              <Route path="/cliente/estoque" element={<ClientPortal />} />
              <Route path="/cliente/impressoras" element={<ClientPortal />} />
              <Route path="/cliente/projetos" element={<ClientPortal />} />
              <Route path="/cliente/ia-copilot" element={<ClientPortal />} />
              <Route path="/cliente/planos" element={<ClientPortal />} />
              <Route path="/cliente/faturas" element={<ClientPortal />} />
              <Route path="/cliente/configuracoes" element={<ClientPortal />} />

              {/* Fallback */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        </TooltipProvider>
      </SaaSDataProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;