import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.example.azureotterspin',
  appName: 'azure-otter-spin',
  webDir: 'dist'
};

export default config;
